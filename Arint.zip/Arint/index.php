
<html>

<head>
    <link href="http://asierso.com/styles.css" type="text/css" rel="stylesheet" />
    <link href="styles.css" type="text/css" rel="stylesheet" />
    <link href="http://asierso.com/Assets/logo.png" rel="icon" type="image/png" />
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />
    <title>Arint</title>
</head>

<body>
    <!--Title-->
    <div class="mainContent">
        <img class="mainLogo" src="http://asierso.com/Assets/logo2.png">
        <h1 class="mainContentFont">Asierso Studio</h1>
    </div>
    <!--Subcontent-->
    <!--1-->
    <div class="subcontent">
        <div style="float: left;width:70px;height:15px;" class="btnIcons"></div>
        <h3 class="font">Arint</h3>
        <p class="font">Una inteligencia artificial que aprende del usuario<br>programada en c#</p>
        <form method="post">
            <p class="font">
                Escribir: <input type="text" name="talk" class="input" />
                <br>
                <br>
                Respuesta:<input type="text" name="answer" class="input2" value="<?php
                                                                                    if (isset($_POST['run'])) {
                                                                                        $result =  system('mono Arint.exe ' . '"' . $_POST['talk'] . '"');
                                                                                        if ($result == "") {
                                                                                            echo "No tengo respuesta para eso :(";
                                                                                        } else {
                                                                                            $result = substr($result, 0, strlen($result) / 2 - strlen($result) / 2);
                                                                                            echo $result;
                                                                                        }
                                                                                    } else {
                                                                                        echo "";
                                                                                    }
                                                                                    ?>" readonly />
                <br>
                <br>
                <button name="run" class="button">Hablar con Arint</button>
            </p>
        </form>
    </div>
    <div class="subcontent">
        <div style="float: left;width:70px;height:15px;" class="btnIcons"></div>
        <h3 class="font">Entrenar</h3>
        <form method="post">
            <p class="font">Cuando digas
                <input type="text" name="say1" class="input" style="width:40%;margin:10px;" />
                tengo que responder<input type="text" name="say2" class="input" style="width:40%;margin:10px;" />
                <button name="teach" class="button">Aprender</button>
            </p>
        </form>
        <div class="subcontent" style="background-color: rgb(100,100,100);">
            <?php
            if (isset($_POST['teach'])) {
                if (strpos($_POST['say1'], 'á') == true || strpos($_POST['say1'], 'é') == true || strpos($_POST['say1'], 'í') == true || strpos($_POST['say1'], 'ó') == true || strpos($_POST['say1'], 'ú') == true || strpos($_POST['say2'], 'á') == true || strpos($_POST['say2'], 'é') == true || strpos($_POST['say2'], 'í') == true || strpos($_POST['say2'], 'ó') == true || strpos($_POST['say2'], 'ú') == true || strpos($_POST['say1'], 'ñ') == true || strpos($_POST['say2'], 'ú') == true || strpos($_POST['say1'], 'ç') == true || strpos($_POST['say2'], 'ç') == true) {
                    echo "<p class=\"font\" style=\"color: white;\">" . "Las tildes y las ñ han sido baneadas" . "</p>";
                } else {
                    echo "<p class=\"font\" style=\"color: white;\">" . "Gracias por alimentar mi base de datos" . "</p>";
                    $result =  system('mono Arint.exe /train ' . '"' . $_POST['say1'] . '" "' . $_POST['say2'] . '"');
                }
            }
            ?>
        </div>
    </div>
    <div class="subcontent">
        <div style="float: left;width:70px;height:15px;" class="btnIcons"></div>
        <h3 class="font">Pol&iacute;ticas</h3>
        <p class="font">Arint recopila datos del usuario para mejorar su sistema de reconocimiento<br>y para crear definiciones a los topicos hablados con Arint<br>Esta informaci&oacute;n se destruye cada 24h <br>(Exceptuando los datos introducidos en el apartado de entrenar)</p>
    </div>
    <div class="subcontent">
       <div style="float: left;width:70px;height:15px;" class="btnIcons"></div>
        <h3 class="font">Servidor</h3>
        <p class="font">Arint es hosteada por el servidor general.<br> Estará activo siempre que ponga el simbolo: </p>
        <img src="http://asierso.com/Assets/server0.png" />
    </div>

</body>
<footer>
    <p class="font">Ver 1.1</p>
</footer>

</html>
