using System;
using System.Collections.Generic;
namespace Arint
{
    class Recognise : IRecognise
    {
        protected Rastered rastered;
        protected List<string> compareResult = new List<string>();
        protected List<Machine> ml;
        public Recognise(Rastered rastered,List<Machine> ml)
        {
            this.rastered = rastered;
            this.ml = ml;
        }
        public virtual void CompareText()
        {
            foreach(string rasteredTextSingle in rastered.textParts)
            {
                foreach(Machine mlSingle in ml)
                {
                    if(mlSingle.humanQuest == rasteredTextSingle)
                    {
                        compareResult.Add(mlSingle.botRespond);
                    }
                }
            }
        }
        public virtual void CompareTextBySimilarMatches()
        {
            int matchesFounded = 0;
            int comparerPointer = 0;
            foreach (string rasteredTextSingle in rastered.textParts)
            {
                
                foreach (Machine mlSingle in ml)
                {
                    matchesFounded = 0;
                    comparerPointer = 0;
                    int totalMatches = mlSingle.humanQuest.Length;
                    
                    foreach(char rasteredTextSingleByChar in rasteredTextSingle)
                    {
                        try
                        {
                            if (rasteredTextSingleByChar == mlSingle.humanQuest[comparerPointer])
                            {
                                matchesFounded++;
                            }
                            comparerPointer++;
                        }
                        catch
                        {

                        }
                    }
                    if (matchesFounded + 1 >= totalMatches)
                    {
                        //Matching
                        compareResult.Remove("@");
                        compareResult.Add(mlSingle.botRespond);
                    }
                }
            }
        }
        public virtual void CompareReverseTextBySimilarMatches()
        {
            int matchesFounded = 0;
            foreach (string rasteredTextSingle in rastered.textParts)
            {

                foreach (Machine mlSingle in ml)
                {
                    matchesFounded = 0;
                    int totalMatches = mlSingle.humanQuest.Length;
                    for (int i = mlSingle.botRespond.Length; i>=0;i--)
                    {
                        try
                        {
                            if (rasteredTextSingle[i] == mlSingle.humanQuest[i])
                            {
                                matchesFounded++;
                            }
                        }
                        catch
                        {
                            
                        }
                    }
                    if (matchesFounded + 1 >= totalMatches)
                    {
                        //Matching
                        compareResult.Remove("@");
                        compareResult.Add(mlSingle.botRespond);
                    }
                }
            }
        }
        public int GetResultNumber()
        {
            try
            {
                return compareResult.ToArray().Length;
            }
            catch
            {
                return 0;
            }
        }
        public List<string> GetAllResults()
        {
            return compareResult;
        }
        public string GetRandomResult()
        {
            Random rdn = new Random();
            return compareResult[rdn.Next(0, compareResult.ToArray().Length)];
        }
    }
}