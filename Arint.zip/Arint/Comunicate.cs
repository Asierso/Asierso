﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Arint
{
    abstract class Comunicate
    {
        public string humanQuest;
        public string botRespond;
        public abstract string[] GetAllParameters();
    }
}
