﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Arint
{
    enum BotRequest { Application, WebService };
    class Historial : Comunicate
    {
        public DateTime date;
        public BotRequest botRequest;
        public Historial(string humanQuest, string botRespond, DateTime date,BotRequest  botRequest)
        {
            this.humanQuest = humanQuest;
            this.botRespond = botRespond;
            this.date = date;
            this.botRequest = botRequest;
        }

        public override string[] GetAllParameters()
        {
            return new string[] {humanQuest,botRespond,date.ToString(),botRequest.ToString()};
        }
    }
}
