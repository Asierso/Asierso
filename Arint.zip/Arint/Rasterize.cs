namespace Arint
{
    class Rastered
    {
        public string[] textParts;
        public Rastered(string text)
        {
            textParts = text.Split(' ');
        }
    }
}