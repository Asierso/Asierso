﻿using System;
using System.IO;
using System.Collections.Generic;
using Newtonsoft.Json;
namespace Arint
{
    class Program
    {
        static void Main(string[] args)
        {
            bool isRuning = true;
            List<Machine> machineLearning = new List<Machine>();
            List<Historial> historial = new List<Historial>();
            machineLearning.Add(new Machine("@", "@"));
            historial.Add(new Historial("@", "@",DateTime.Now,BotRequest.Application));
            machineLearning.Add(new Machine("/exit", "Cerrando", true));
            Directory.CreateDirectory("ml");
            if(!File.Exists("ml/registDate.dat"))
            {
                using (StreamWriter createdateregist = new StreamWriter("ml/registDate.dat"))
                {
                    createdateregist.Write(DateTime.Now.Day);
                    createdateregist.Close();
                }
            }
            else
            {
                Security sec = new Security("history.json");
                sec.Backup();
                sec = new Security("mlbot.json");
                sec.Backup();
                using (StreamReader checkdateregist = new StreamReader("ml/registDate.dat"))
                {
                    int dayReaded = Convert.ToInt32(checkdateregist.ReadToEnd());
                    int currentDay = DateTime.Now.Day;
                    if(dayReaded != currentDay)
                    {
                        File.Delete("ml/history.json");
                    }
                    checkdateregist.Close();
                }
                using (StreamWriter createdateregist = new StreamWriter("ml/registDate.dat"))
                {
                    createdateregist.Write(DateTime.Now.Day);
                    createdateregist.Close();
                }
            }
            if (!File.Exists("ml/mlbot.json"))
            {
                using (StreamWriter createml = new StreamWriter("ml/mlbot.json"))
                {
                    List<Machine> machineLearningDefault = new List<Machine>();
                    machineLearningDefault = machineLearning;
                    createml.Write(JsonConvert.SerializeObject(machineLearningDefault.ToArray(), Formatting.Indented));
                    createml.Close();
                }
            }
            if (!File.Exists("ml/history.json"))
            {
                using (StreamWriter createml = new StreamWriter("ml/history.json"))
                {
                    List<Historial> historialDefault = new List<Historial>();
                    historialDefault = historial;
                    createml.Write(JsonConvert.SerializeObject(historialDefault.ToArray(), Formatting.Indented));
                    createml.Close();
                }
            }
            historial.Clear();
            using (StreamReader readerMlbot = new StreamReader("ml/mlbot.json"))
            {
                machineLearning = JsonConvert.DeserializeObject<List<Machine>>(readerMlbot.ReadToEnd());
                readerMlbot.Close();
            }
            using (StreamReader readerMlbot = new StreamReader("ml/history.json"))
            {
                historial = JsonConvert.DeserializeObject<List<Historial>>(readerMlbot.ReadToEnd());
                readerMlbot.Close();
            }
            try
            {
                bool findAnswer = false;
                if (args[0] == "/train")
                {
                    machineLearning.Add(new Machine(args[1], args[2]));
                    using (StreamWriter writeJson = new StreamWriter("ml/mlbot.json"))
                    {
                        writeJson.Write(JsonConvert.SerializeObject(machineLearning.ToArray(), Formatting.Indented));
                        writeJson.Close();
                    }
                    //Console.Write("Gracias por alimentar mi base de datos");
                }
                else if (args[0].Length > 0)
                {
                    string answer = "";
                    List<string> answerList = new List<string>();
                    foreach (Machine machineLearningSingle in machineLearning)
                    {
                        if (machineLearningSingle.humanQuest == args[0])
                        {
                            answer = machineLearningSingle.botRespond;
                            answerList.Add(machineLearningSingle.botRespond);
                            findAnswer = true;
                        }
                    }
                    if (findAnswer == false)
                    {
                        Recognise recognise = new Recognise(new Rastered(args[0]), machineLearning);
                        recognise.CompareText();
                        if (recognise.GetResultNumber() == 0)
                        {
                            recognise.CompareTextBySimilarMatches();
                            if(recognise.GetAllResults()[0].ToString() == "@")
                            {

                            }
                            else
                            {
                                answer = recognise.GetRandomResult();
                                Console.WriteLine(answer);
                                findAnswer = true;
                                Console.ResetColor();
                            }
                        }
                        else
                        {
                            answer = recognise.GetRandomResult();
                            Console.WriteLine(answer);
                            findAnswer = true;
                            Console.ResetColor();
                        }

                    }
                    else
                    {
                        Random rdn = new Random();
                        answer = answerList[rdn.Next(0, answerList.ToArray().Length)];
                        Console.WriteLine(answer);
                    }
                    if(findAnswer == true)
                    {
                        historial.Add(new Historial(args[0], answer, DateTime.Now, BotRequest.WebService));
                    }
                    using (StreamWriter writeJson = new StreamWriter("ml/history.json"))
                    {
                        writeJson.Write(JsonConvert.SerializeObject(historial.ToArray(), Formatting.Indented));
                        writeJson.Close();
                    }
                }
            }
            catch
            {
                while (isRuning == true)
                {
                    List<string> answerList = new List<string>();
                    answerList.Clear();
                    Console.Write("YOU: ");
                    string userQuest = Console.ReadLine();
                    bool findAnswer = false;
                    string answer = "";
                    foreach (Machine machineLearningSingle in machineLearning)
                    {
                        if (machineLearningSingle.humanQuest == userQuest)
                        {
                            if (machineLearningSingle.isCommand == true)
                            {
                                switch (machineLearningSingle.humanQuest)
                                {
                                    case "/exit": isRuning = false; Console.ForegroundColor = ConsoleColor.Yellow; break;
                                }
                            }
                            answer = machineLearningSingle.botRespond;
                            answerList.Add(machineLearningSingle.botRespond);
                            findAnswer = true;
                            Console.ResetColor();
                        }
                    }
                    if (findAnswer == false)
                    {
                        Recognise recognise = new Recognise(new Rastered(userQuest), machineLearning);
                        recognise.CompareText();
                        if(recognise.GetResultNumber() == 0)
                        {
                            recognise.CompareTextBySimilarMatches();
                            if (recognise.GetAllResults()[0].ToString() == "@")
                            {
                                recognise.CompareReverseTextBySimilarMatches();
                                if (recognise.GetAllResults()[0].ToString() == "@")
                                {
                                    Console.WriteLine("BOT: No tengo respuesta para eso. Cuando digas " + userQuest + " yo digo");
                                    Console.Write("YOU: ");
                                    string userTeach = Console.ReadLine();
                                    machineLearning.Add(new Machine(userQuest, userTeach));
                                }
                                else
                                {
                                    answer = recognise.GetRandomResult();
                                    Console.WriteLine("BOT: " + answer);
                                    findAnswer = true;
                                    Console.ResetColor();
                                }

                            }
                            else
                            {
                                answer = recognise.GetRandomResult();
                                Console.WriteLine("BOT: " + answer);
                                findAnswer = true;
                                Console.ResetColor();
                            }
                        }
                        else
                        {
                            answer = recognise.GetRandomResult();
                            Console.WriteLine("BOT: " + answer);
                            findAnswer = true;
                            Console.ResetColor();
                        }
                        
                    }
                    else
                    {
                        Random rdn = new Random();
                        Console.WriteLine("BOT: " + answerList[rdn.Next(0, answerList.ToArray().Length)]);
                    }
                    if (findAnswer == true)
                    {
                        historial.Add(new Historial(userQuest, answer, DateTime.Now, BotRequest.Application));
                    }
                    using (StreamWriter writeJson = new StreamWriter("ml/history.json"))
                    {
                        writeJson.Write(JsonConvert.SerializeObject(historial.ToArray(), Formatting.Indented));
                        writeJson.Close();
                    }
                    using (StreamWriter writeJson = new StreamWriter("ml/mlbot.json"))
                    {
                        writeJson.Write(JsonConvert.SerializeObject(machineLearning.ToArray(), Formatting.Indented));
                        writeJson.Close();
                    }
                }
            }
        }
    }
}
