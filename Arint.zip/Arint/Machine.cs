namespace Arint
{
    class Machine : Comunicate
    {
        
        public bool isCommand;
        public Machine(string humanQuest,string botRespond,bool isCommand = false)
        {
            this.humanQuest = humanQuest;
            this.botRespond = botRespond;
            this.isCommand = isCommand;
        }

        public override string[] GetAllParameters()
        {
            return new string[] { humanQuest,botRespond, isCommand.ToString() };
        }
    }
}