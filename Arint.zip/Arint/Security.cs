﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Arint
{
    class Security
    {
        private string file;
        public Security(string file)
        {
            this.file = file;
        }
        public void Backup()
        {
            int day;
            using(StreamReader str = new StreamReader("ml/registDate.dat"))
            {
                day = Int32.Parse(str.ReadToEnd());
                str.Close();
            }
            if(day != DateTime.Now.Day)
            {
                Directory.CreateDirectory("back");
                using (StreamWriter stw = new StreamWriter("back/" + Path.GetFileNameWithoutExtension(file) + "_" + DateTime.Now.Day.ToString() + Path.GetExtension(file)))
                {
                    StreamReader str = new StreamReader("ml/" + file);
                    stw.Write(str.ReadToEnd());
                    str.Close();
                    stw.Close();
                }
            }
        }
    }
}
